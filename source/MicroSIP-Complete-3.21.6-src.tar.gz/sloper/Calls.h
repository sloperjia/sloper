/*
 * Copyright (C) 2011-2024 MicroSIP (http://www.microsip.org)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#pragma once

#include "resource.h"
#include "global.h"
#include "BaseDialog.h"
#include "CListCtrl_SortItemsEx.h"
#include "CSVFile.h"
#include "Markup.h"

class Calls :
	public CBaseDialog
{
public:
	Calls(CWnd* pParent = NULL);	// standard constructor
	~Calls();
	enum { IDD = IDD_CALLS };
	void TabFocusSet() override {};
	bool GotoTab(int i, CTabCtrl* tab) { return false; };
	void ProcessCommand(CString str) override {};

	CListCtrl_SortItemsEx m_SortItemsExListCtrl;

	int Get(CString id);
	void Add(pj_str_t id, CString number, CString name, int type, call_user_data *user_data);
	void SetName(pj_str_t id, CString name);
	void SetDuration(pj_str_t id, int sec);
	void SetInfo(pj_str_t id, CString str);
	void Delete(int i);
	void DeleteAll();
	void UpdateCallButton();

	void CallsLoad();
	void CallsClear();
	CString FormatTime(int time, CTime *pTimeNow = NULL);
	void ReloadTime();
	bool isFiltered(Call *pCall = NULL);
	void filterReset();

	void OnCreated();

private:
	CImageList* imageList;
	int lastDay;
	int lastKey;
	void CallSave(Call *pCall);
	void CallDecode(CString str, Call *pCall);
	CString CallEncode(Call *pCall);
	void Insert(Call *pCall, int pos = 0);
	void MessageDlgOpen(BOOL isCall = FALSE, BOOL hasVideo = FALSE);
	void DefaultItemAction(int i);
	int GetNextKey(bool noInc = false);
	void SaveKey();

protected:
	virtual BOOL OnInitDialog();
	afx_msg void OnTimer(UINT_PTR TimerVal);
	virtual void PostNcDestroy();
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
	afx_msg void OnFilterValueChange();
	afx_msg void OnMenuCall(); 
	afx_msg void OnMenuChat();
	afx_msg void OnMenuAdd();
	afx_msg void OnMenuCopy();
	afx_msg void OnMenuDelete(); 
	afx_msg void OnMenuExport();
	afx_msg LRESULT OnContextMenu(WPARAM wParam,LPARAM lParam);
	afx_msg void OnNMDblclkCalls(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnEndtrack(NMHDR* pNMHDR, LRESULT* pResult);
#ifdef _GLOBAL_VIDEO
	afx_msg void OnMenuCallVideo(); 
#endif
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

