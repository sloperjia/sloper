#pragma once 

#include "const.h"

class CIconButton : public CButton 
{ 
	DECLARE_DYNAMIC(CIconButton) 
public: 
	CIconButton();
	virtual ~CIconButton();
};
