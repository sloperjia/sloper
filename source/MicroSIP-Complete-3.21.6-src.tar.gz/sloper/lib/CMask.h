#pragma once
#include "stdafx.h"

class CMask
{
public:
	BOOL WildMatch(CString sWild, CString sString, CString sLimitChar);
};
