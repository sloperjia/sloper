// CIconButton.cpp : implementation file   
//   
#include "StdAfx.h"   
#include "IconButton.h"   

// CIconButton   
IMPLEMENT_DYNAMIC(CIconButton, CButton)
CIconButton::CIconButton()   
{   
}
   
CIconButton::~CIconButton()   
{   
}

